/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warstwa_biznesowa;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Cezary
 */
public class Facade {
    private List<City> cityList;
    private List<Client> clientList;
    private Factory factory;
    private Client client;
    
    public Facade()
    {
        factory = new Factory();
        client = new Client("test@gmail.com", "haslo", "Jan", "Nowak", "Wroclaw");
    }
    
    public boolean AddCity(String name)
    {
        if(FindCity(name)==null){
        City city = factory.CreateCity(name);
        cityList.add(city);
        return true;
        }
        return false;
    }
    
    public boolean AddHotel(String cityName, String name, String address)
    {
        //Walidacja
        if(name==null){
            System.out.println("Błąd danych!");
        return false;
        }
        
        if(FindCity(cityName)==null)
        {
            AddCity(cityName);
        }
        City city=FindCity(cityName);
        
        if(city.FindHotel(name)==null)
        {
            System.out.println("Taki Hotel już istnieje!");
            return false;
        }
        
        city.AddHotel(name, address);
        System.out.println("Hotel został dodany prawidłowo - Fasada");
        return true;
    }
    
    public boolean AddRoom(Hotel hotel)
    {
        return false;
    }
    
    public boolean AddClient(String email, String password)
    {
        return false;
    }
    
    public City FindCity(String name)
    {
        for(City city : cityList) //https://www.baeldung.com/find-list-element-java
        {
            if(city.name==name) return city;
        }
        return null;
    }
    
    public Hotel FindHotel(String name)
    {
        return null;
    }
    
    public Room FindRoom(Hotel hotel, int size)
    {
        return null;
    }
    
    public Reservation FindReservation(Room room, Date date)
    {
        if(room == null)
        {
            return null;
        }
        
        return room.GetReservation(date);
    }
    
    public Client FindClient()
    {
        return null;
    }
    
    public List GetClientReservations(Client client)
    {
        return null;
    }
    
    public void MakeReservation(Room room, Date date)
    {
        if(this.FindReservation(room, date) != null)
        {
            System.out.println("Pokój jest już zarezerwowany!");
        }
        else
        {
            Reservation reservation = factory.CreateReservation(date, client);
            room.reservationList.add(reservation);
            client.reservationList.add(reservation); // dopytać czy można to wrzucić do konstruktora Reservation + czy trzeba zmieniać diagram sekwencji
            
            System.out.println("Rezerwacja została dokonana");
        }
    }
    
    public void CancelReservation(Reservation reservation)
    {
        
    }
    
    public void DeleteClient()
    {
    }
}
