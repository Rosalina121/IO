/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warstwa_biznesowa;

import java.util.List;

/**
 *
 * @author Cezary
 */
public class City {
    protected String name;
    protected String country;
    
    private List<Hotel> hotelList;
    
    public City(String name)
    {
        this.name = name;
        this.country = null;
    }
    
    public void SetName(String name)
    {
        this.name = name;
    }
    
    public void SetCountry(String country)
    {
        this.country = country;
    }
    
    public String GetName()
    {
        return this.name;
    }
    
    public String GetCountry()
    {
        return this.country;
    }
    
    public List GetHotelList()
    {
        return this.hotelList;
    }
    
    public boolean AddHotel(String name, String address)
    {
        Hotel hotel = new Hotel(name, address);
        hotelList.add(hotel);
        System.out.println("Hotel został dodany prawidłowo - City");
        return true;
    }
    
    public Hotel FindHotel(String name)
    {
        for(Hotel hotel : hotelList) //https://www.baeldung.com/find-list-element-java
        {
            if(hotel.name == name)
            {
                return hotel;
            }
        }
        return null;
    }
}
